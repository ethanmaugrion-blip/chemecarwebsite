# CU Boulder Chem-E-Car website

A static site: one page (`index.html`) plus the logo in `assets/`. No build step, no server code.

## What's in here

- `index.html`: the whole site (Home, Calendar, Join, About), with its styles and script inside.
- `assets/cu-logo.png`: the header logo, also used as the browser-tab icon.

## Put it online with GitHub Pages (free)

1. Create a free GitHub account and a new **public** repository (for example `chemecar-site`).
2. Upload `index.html` and the `assets` folder to the repository (Add file > Upload files). `index.html` must sit at the top level, not inside a subfolder.
3. In the repository, open Settings > Pages. Under "Build and deployment", choose "Deploy from a branch", pick the `main` branch and the `/ (root)` folder, then save.
4. After a minute or two the site is live at `https://YOUR-USERNAME.github.io/chemecar-site/`.

## Use your own domain

1. Buy a domain from any registrar.
2. In Settings > Pages, type the domain into "Custom domain" and save. GitHub adds a `CNAME` file to the repository for you.
3. At your registrar, add the DNS records GitHub's Pages documentation lists for a custom domain (a CNAME record for `www`, and A records for the bare domain).
4. Once the DNS check passes, tick "Enforce HTTPS" in Settings > Pages.

## Editing the site after it's hosted

The gold EDIT button only works inside Claude, where the site was built. On your own hosting, change `index.html` directly (GitHub lets you edit it in the browser with the pencil icon) and commit; the live site updates in a minute or two.

To add a calendar event, find `id="eventList"` in `index.html`, copy one whole `<div class="event" ...> ... </div>` block, and change:

- `data-date="2026-11-08"`: the date, as year-month-day.
- the title and the line under it.
- for an event that repeats every week, add `data-repeat="weekly"` (and, if it should stop, `data-until="2027-05-01"`).

The big date label, the month grid and the "Next up" card all update from `data-date` on their own.

## Things to know

- Fonts load from Google Fonts, so the site needs an internet connection to look right.
- The photo on the About page is loaded from colorado.edu. If that link ever breaks, save a photo into `assets/` and point the `aboutPhoto` background image at it.
